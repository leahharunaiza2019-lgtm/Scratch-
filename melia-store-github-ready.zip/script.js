const PRODUCTS = [
  {id:1,name:"Elegant Dress",category:"Fashion",price:45,icon:"👗",desc:"A graceful everyday dress with a polished finish."},
  {id:2,name:"Classic Outfit",category:"Fashion",price:55,icon:"✨",desc:"A versatile look for casual and special moments."},
  {id:3,name:"Melia Handbag",category:"Bags",price:35,icon:"👜",desc:"A chic everyday bag designed to complement your look."},
  {id:4,name:"Jewelry Set",category:"Jewelry",price:25,icon:"💎",desc:"A delicate set for an effortless finishing touch."},
  {id:5,name:"Silk Scarf",category:"Fashion",price:18,icon:"🧣",desc:"A soft statement scarf for an elegant accent."},
  {id:6,name:"Mini Shoulder Bag",category:"Bags",price:32,icon:"👝",desc:"Compact, stylish and ready for your essentials."},
  {id:7,name:"Glow Beauty Set",category:"Beauty",price:29,icon:"✨",desc:"A simple beauty collection for your daily routine."},
  {id:8,name:"Pearl Earrings",category:"Jewelry",price:22,icon:"🤍",desc:"Classic pearls with a modern Melia feel."}
];

let cart = JSON.parse(localStorage.getItem("meliaCart") || "[]");
let category = "All";

const $ = s => document.querySelector(s);
const money = n => `$${n.toFixed(2)}`;

function save(){localStorage.setItem("meliaCart",JSON.stringify(cart));}
function renderProducts(){
  const term = $("#search").value.trim().toLowerCase();
  const list = PRODUCTS.filter(p => (category==="All" || p.category===category) &&
    (p.name.toLowerCase().includes(term) || p.category.toLowerCase().includes(term)));
  $("#products").innerHTML = list.map(p => `
    <article class="product">
      <div class="product-image">${p.icon}</div>
      <div class="product-body">
        <div class="product-cat">${p.category}</div>
        <h3>${p.name}</h3>
        <p class="product-desc">${p.desc}</p>
        <div class="product-bottom">
          <span class="price">${money(p.price)}</span>
          <button class="add" aria-label="Add ${p.name}" onclick="addToCart(${p.id})">+</button>
        </div>
      </div>
    </article>`).join("");
  $("#emptyProducts").hidden = list.length !== 0;
}
function addToCart(id){
  const found = cart.find(i=>i.id===id);
  if(found) found.qty++; else cart.push({id,qty:1});
  save(); renderCart(); openCart(); toast("Added to your cart");
}
function changeQty(id,delta){
  const item=cart.find(i=>i.id===id); if(!item)return;
  item.qty+=delta; if(item.qty<=0)cart=cart.filter(i=>i.id!==id);
  save(); renderCart();
}
function renderCart(){
  const count=cart.reduce((a,i)=>a+i.qty,0);
  $("#cartCount").textContent=count;
  if(!cart.length){
    $("#cartItems").innerHTML='<div class="empty">Your cart is waiting for something beautiful. 💜</div>';
  } else {
    $("#cartItems").innerHTML=cart.map(i=>{
      const p=PRODUCTS.find(x=>x.id===i.id);
      return `<div class="cart-row">
        <div class="mini-image">${p.icon}</div>
        <div><strong>${p.name}</strong><div class="qty">
          <button onclick="changeQty(${p.id},-1)">−</button><span>${i.qty}</span><button onclick="changeQty(${p.id},1)">+</button>
          <button class="remove" onclick="changeQty(${p.id},-${i.qty})">Remove</button>
        </div></div>
        <strong>${money(p.price*i.qty)}</strong>
      </div>`;
    }).join("");
  }
  const total=cart.reduce((sum,i)=>sum+PRODUCTS.find(p=>p.id===i.id).price*i.qty,0);
  $("#cartTotal").textContent=money(total);
}
function openCart(){
  $("#cartDrawer").classList.add("open");$("#overlay").classList.add("show");
  $("#cartDrawer").setAttribute("aria-hidden","false");
}
function closeCart(){
  $("#cartDrawer").classList.remove("open");$("#overlay").classList.remove("show");
  $("#cartDrawer").setAttribute("aria-hidden","true");
}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}

$("#filters").addEventListener("click",e=>{
  const b=e.target.closest(".filter"); if(!b)return;
  category=b.dataset.category;
  document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));b.classList.add("active");
  renderProducts();
});
$("#search").addEventListener("input",renderProducts);
$("#openCart").onclick=openCart; $("#closeCart").onclick=closeCart; $("#overlay").onclick=closeCart;
$("#clearCart").onclick=()=>{cart=[];save();renderCart();toast("Cart cleared")};
$(".menu-toggle").onclick=()=>$(".nav").classList.toggle("open");
document.querySelectorAll(".nav a").forEach(a=>a.onclick=()=>$(".nav").classList.remove("open"));

$("#checkoutBtn").onclick=()=>{
  if(!cart.length){toast("Add an item before checkout");return;}
  $("#checkoutModal").showModal();
};

$("#checkoutForm").addEventListener("submit",e=>{
  e.preventDefault();
  const name=$("#customerName").value.trim(), email=$("#customerEmail").value.trim();
  const phone=$("#customerPhone").value.trim(), address=$("#customerAddress").value.trim();
  const notes=$("#customerNotes").value.trim();
  const lines=cart.map(i=>{const p=PRODUCTS.find(x=>x.id===i.id);return `${p.name} x ${i.qty} — ${money(p.price*i.qty)}`}).join("%0D%0A");
  const total=cart.reduce((s,i)=>s+PRODUCTS.find(p=>p.id===i.id).price*i.qty,0);
  const body=`Hello Melia,%0D%0A%0D%0AI would like to place an order.%0D%0A%0D%0ACustomer: ${encodeURIComponent(name)}%0D%0AEmail: ${encodeURIComponent(email)}%0D%0APhone: ${encodeURIComponent(phone)}%0D%0ADelivery address: ${encodeURIComponent(address)}%0D%0A%0D%0AItems:%0D%0A${lines}%0D%0A%0D%0ATotal: ${money(total)}%0D%0A%0D%0ANotes: ${encodeURIComponent(notes || "None")}%0D%0A%0D%0AThank you.`;
  window.location.href=`mailto:Leahharunaiza2019@gmail.com?subject=${encodeURIComponent("New Melia Order — "+name)}&body=${body}`;
  $("#checkoutModal").close();
});

renderProducts();renderCart();
