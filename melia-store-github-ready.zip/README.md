# Melia Store

A GitHub-ready storefront for Melia.

## Included

- Responsive purple/lilac storefront
- Product catalogue
- Search and category filters
- Functional cart with quantity controls
- Cart saved in the browser with localStorage
- Checkout form
- Email-order checkout using the Melia email address
- About, contact and future walk-in-store messaging

## Put it online with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css` and `script.js`.
3. Commit the files.
4. Open **Settings → Pages**.
5. Select **Deploy from a branch**.
6. Select the `main` branch and `/ (root)`.
7. Save and wait for GitHub to publish the site.

## Important for real payments

This version accepts orders by email. It does **not** collect card numbers or process payments itself.

For live card/mobile-money payments, connect a payment provider through a secure backend. Never put secret API keys in `index.html` or `script.js`.

## Editing products

Open `script.js` and edit the `PRODUCTS` array. Each product has:

- `name`
- `category`
- `price`
- `icon`
- `desc`

You can later replace the emoji product placeholders with real product images.
